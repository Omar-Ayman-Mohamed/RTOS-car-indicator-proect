
#ifndef TC72_PRIVATE_H_
#define TC72_PRIVATE_H_

#define ONE_SHOT_MODE         0x14
#define CONTINOUS_MODE        0x04

#define CTRL_WRITE_ADD        0x80
#define LSB_TEMP     		  0x01
#define MSB_TEMP     		  0x02

#endif /* TC72_PRIVATE_H_ */