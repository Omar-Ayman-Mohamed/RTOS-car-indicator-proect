
#ifndef TC72_CFG_H_
#define TC72_CFG_H_

#define TC72_PORT DIO_PORTB
#define TC72_PIN  Pin4

#endif /* TC72_CFG_H_ */