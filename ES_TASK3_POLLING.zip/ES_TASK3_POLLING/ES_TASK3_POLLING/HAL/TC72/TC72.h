
#ifndef TC72_H_
#define TC72_H_

#define F_CPU 16000000UL
#include "util/delay.h"

#include "TC72_Cfg.h"
#include "TC72_private.h"
#include "DIO.h"
#include "STD_TYPES.h"
 
void     TC72_init(void);
fint32_t TC72_Get_Data(void);

#endif /* TC72_H_ */