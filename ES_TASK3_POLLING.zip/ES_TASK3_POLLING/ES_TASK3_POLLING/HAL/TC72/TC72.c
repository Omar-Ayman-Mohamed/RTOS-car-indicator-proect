
#include "TC72.h"

void TC72_init(void)
{
	SPI_init();
	DIO_SetPinVal(TC72_PORT,TC72_PIN,HIGH);
	SPI_TranCieve(CTRL_WRITE_ADD);
	SPI_TranCieve(CONTINOUS_MODE);
	DIO_SetPinVal(TC72_PORT,TC72_PIN,LOW);
	_delay_ms(150);
}

fint32_t TC72_Get_Data(void)
{
	uint8_t temp;
	DIO_SetPinVal(TC72_PORT,TC72_PIN,HIGH);
	temp = SPI_TranCieve(MSB_TEMP);
	temp = SPI_TranCieve(0x00);
	DIO_SetPinVal(TC72_PORT,TC72_PIN,LOW);
	
	SPI_TranCieve(temp);
	return temp;
}
