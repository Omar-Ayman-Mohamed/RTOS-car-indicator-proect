
#ifndef LCD_CONFIG_H_
#define LCD_CONFIG_H_

#define LCD_CMD_PORT       DIO_PORTB
#define RS_PIN             Pin1
#define RW_PIN             Pin2
#define E_PIN              Pin3

#define LCD_DATA_PORT      DIO_PORTA
#define LCD_D4_Pin         Pin4
#define LCD_D5_Pin         Pin5
#define LCD_D6_Pin         Pin6
#define LCD_D7_Pin         Pin7

#endif /* LCD_CONFIG_H_ */