
#ifndef LCD_INTERFACE_H_
#define LCD_INTERFACE_H_

#include "DIO.h"
#include "LCD_Cfg.h"
#include "LCD_private.h"
#define F_CPU 16000000UL
#include "util/delay.h"


void LCD_init();
void LCD_Write_CMD(uint8_t CMD);
void LCD_Write_CHAR(uint8_t CHAR);
void LCD_WriteString(const uint8_t * str);

void LCD_WriteNUM(sint64_t NUM);
void LCD_WriteFLOAT(fint64_t num,uint8_t Percision);
void LCD_Clear(void);


#endif /* LCD_INTERFACE_H_ */