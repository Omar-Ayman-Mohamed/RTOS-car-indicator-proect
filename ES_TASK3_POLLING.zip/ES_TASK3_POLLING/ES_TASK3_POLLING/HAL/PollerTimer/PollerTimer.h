
#ifndef POLLERTIMER_H_
#define POLLERTIMER_H_

void StartTimer(void);
void StopTimer(void);
void CallPollingFunction(void);

#endif /* POLLERTIMER_H_ */