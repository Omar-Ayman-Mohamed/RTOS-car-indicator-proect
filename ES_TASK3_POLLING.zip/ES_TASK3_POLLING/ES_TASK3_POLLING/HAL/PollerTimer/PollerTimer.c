
#include "PollerTimer.h"

void StartTimer(void)
{
	Timer0_INIT();
	Timer0_Start();
}

void StopTimer(void)
{
	Timer0_Stop();
}

void CallPollingFunction(void)
{
	Poll();
}