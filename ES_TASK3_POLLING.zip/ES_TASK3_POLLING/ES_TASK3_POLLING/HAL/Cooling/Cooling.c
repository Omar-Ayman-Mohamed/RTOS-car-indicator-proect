

#include "Cooling.h"

void Handle_data(fint32_t data)
{
	if(data>900.0)
	{
	}
	else
	{
	}
}
