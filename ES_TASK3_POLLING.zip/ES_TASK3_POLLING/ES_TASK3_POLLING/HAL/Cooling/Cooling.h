
#ifndef COOLING_H_
#define COOLING_H_

#include "STD_TYPES.h"

void Cooling_Handle_data(fint32_t data);


#endif /* COOLING_H_ */