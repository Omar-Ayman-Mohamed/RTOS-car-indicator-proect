
#ifndef POLLER_H_
#define POLLER_H_

#include "STD_TYPES.h"
#include "TC72.h"
#include "Cooling.h"
#include "LCD.h"

void Poll(void);
void StartPolling(void);
void StopPolling(void);
void SetPollingTime(uint16t polling_time);

#endif /* POLLER_H_ */