
#include "POLLER.h"

uint8_t polling_enabled = 1;
uint16t polling_counter = 1;
uint16t counter = 0 ;

void Poll(void)
{
	if(polling_enabled && (!counter))
	{
		fint32_t data;
		data = TC72_Get_Data();
		LCD_Write_CMD(CMD_Return_Home);
		LCD_WriteFLOAT(data,2);
		LCD_WriteString(" oC");
		//Cooling_Handle_data(data);
	}
	counter++;
	counter = counter % polling_counter;
}

void StartPolling(void)
{
	polling_enabled = 1;
}

void StopPolling(void)
{
	polling_enabled = 0;
}

void SetPollingTime(uint16t polling_time)
{
	polling_counter = polling_time / 100;
}
