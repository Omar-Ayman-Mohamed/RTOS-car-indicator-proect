#define F_CPU 16000000UL
#include "util/delay.h"

#include "Cooling.h"
#include "TC72.h"
#include "POLLER.h"
#include "PollerTimer.h"
#include "LCD.h"

#include "DIO.h"
#include "INT.h"
#include "TIMER.h"
#include "SPI.h"

int main(void)
{
	TC72_init();
	LCD_init();
	StartTimer();
	GIE();
	SetPollingTime(500);
	StartPolling();
	while(1)
	{

	}
}

ISR(TIMER0_COMP_vect)
{
	CallPollingFunction();
}