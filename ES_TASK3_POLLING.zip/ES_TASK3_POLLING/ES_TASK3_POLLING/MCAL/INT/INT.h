
#ifndef INT_H_
#define INT_H_

#include "INT_private.h"
#include "BIT_MATH.h"
#include "STD_TYPES.h"
#include <avr/interrupt.h>

void GIE();
void GID();
	
#endif /* EX_INT_INTERFACE_H_ */