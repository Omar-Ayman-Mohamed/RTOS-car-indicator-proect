
#include "INT.h"

void GIE()
{
    SET_BIT(SREG,I_BIT);
}
void GID()
{
	CLR_BIT(SREG,I_BIT);
}
