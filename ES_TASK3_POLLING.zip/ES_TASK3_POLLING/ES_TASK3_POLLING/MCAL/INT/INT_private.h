
#ifndef INT_PRIVATE_H_
#define INT_PRIVATE_H_

#define  SREG	  (*((volatile uint8_t *)(0x5F)))
#define  I_BIT	   7

#endif /* EX_INT_PRIVATE_H_ */