
#ifndef SPI_INTERFACE_H_
#define SPI_INTERFACE_H_

#include "SPI_private.h"
#include "BIT_MATH.h"
#include "DIO.h"

void    SPI_init (void);
uint8_t SPI_TranCieve(uint8_t Data);

#endif /* SPI_INTERFACE_H_ */