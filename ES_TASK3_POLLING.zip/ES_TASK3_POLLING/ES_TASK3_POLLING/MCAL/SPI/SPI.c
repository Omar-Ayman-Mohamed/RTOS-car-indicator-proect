
#include "SPI.h"

void SPI_init (void)
{	
	SPI_DDR |= ((1<<MOSI_PIN) | (1<<SS_PIN) | (1<<SCK_PIN));
	SPCR     =(1<<SPE)|(1<<MSTR)|(1<<SPR1)|(1<<SPR0)|(1<<CPHA);
}

uint8_t SPI_TranCieve(uint8_t Data)
{
	SPDR = Data ;
	while(IS_LO(SPSR,SPIF));
	return SPDR;
}