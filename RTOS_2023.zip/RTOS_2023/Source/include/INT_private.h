/*
 * INT_private.h
 *
 *  Created on: Feb 8, 2023
 *      Author: wario
 */

#ifndef SOURCE_INCLUDE_INT_PRIVATE_H_
#define SOURCE_INCLUDE_INT_PRIVATE_H_


#define  SREG	  (*((volatile uint8_t *)(0x5F)))
#define  I_BIT	   7
#endif /* SOURCE_INCLUDE_INT_PRIVATE_H_ */
